package main.pesistence;

import main.businesslogic.shift.ShiftManagerEventReceiver;

public class ShiftPersistence implements ShiftManagerEventReceiver {}
