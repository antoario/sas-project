package main.businesslogic.menu;

public class MenuException extends Exception {
}
