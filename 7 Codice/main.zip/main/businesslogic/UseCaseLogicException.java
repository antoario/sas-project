package main.businesslogic;

public class UseCaseLogicException extends Exception {
}
