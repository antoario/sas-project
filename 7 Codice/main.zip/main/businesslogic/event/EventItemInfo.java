package main.businesslogic.event;

public interface EventItemInfo {
}
