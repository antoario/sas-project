package main.businesslogic;

public class TaskException extends Exception {
}
