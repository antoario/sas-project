package main.businesslogic;

public class ShiftException extends Exception{
}
